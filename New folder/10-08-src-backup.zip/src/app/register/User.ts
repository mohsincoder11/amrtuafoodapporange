export interface User {
  id: number;
  first: string;
  last: string;
}
