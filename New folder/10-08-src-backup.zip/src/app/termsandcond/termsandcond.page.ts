import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsandcond',
  templateUrl: './termsandcond.page.html',
  styleUrls: ['./termsandcond.page.scss'],
})
export class TermsandcondPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
